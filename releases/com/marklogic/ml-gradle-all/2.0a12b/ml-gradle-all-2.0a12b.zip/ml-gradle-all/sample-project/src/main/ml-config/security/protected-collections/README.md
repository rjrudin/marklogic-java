See [the MarkLogic docs](http://docs.marklogic.com/REST/POST/manage/v2/protected-collections) for what a protected 
collection JSON/XML file can contain.