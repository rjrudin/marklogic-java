See [the MarkLogic docs](http://docs.marklogic.com/REST/POST/manage/v2/databases/[id-or-name]/domains) for what a 
CPF domain JSON/XML file can contain.