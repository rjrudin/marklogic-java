See [the MarkLogic docs](http://docs.marklogic.com/REST/POST/manage/v2/certificate-templates) for what a certificate 
template JSON/XML file can contain.