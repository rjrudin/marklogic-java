See [the MarkLogic docs](http://docs.marklogic.com/REST/POST/manage/v2/databases/[id-or-name]/view-schemas) for what a 
SQL view schema and view JSON/XML file can contain.