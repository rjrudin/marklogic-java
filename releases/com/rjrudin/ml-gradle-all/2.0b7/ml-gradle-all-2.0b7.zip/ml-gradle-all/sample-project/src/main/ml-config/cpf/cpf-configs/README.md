See [the MarkLogic docs](http://docs.marklogic.com/REST/POST/manage/v2/databases/[id-or-name]/cpf-configs) for what a 
CPF configuration JSON/XML file can contain.