See [the MarkLogic docs](http://docs.marklogic.com/REST/POST/manage/v2/databases) for what a database JSON/XML file can
contain.

As shown in this directory, you can have multiple files for configuring your content database. See the build.gradle
file to see how more-content-database-config.json is added to the list of content database config files. 
