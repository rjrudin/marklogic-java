See [the MarkLogic docs](http://docs.marklogic.com/REST/POST/manage/v2/external-security) for what an external 
security JSON/XML file can contain.